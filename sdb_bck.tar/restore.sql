--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sdb_course;
--
-- Name: sdb_course; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sdb_course WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE sdb_course OWNER TO postgres;

\connect sdb_course

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE sdb_course; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE sdb_course IS 'spatial database of undemy course';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: baea_nests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.baea_nests (
    gid integer NOT NULL,
    postgis_fi double precision,
    lat_y_dd numeric,
    long_x_dd numeric,
    status character varying(254),
    nest_id double precision,
    geom public.geometry(Point,4326)
);


ALTER TABLE public.baea_nests OWNER TO postgres;

--
-- Name: baea_nests_gid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.baea_nests_gid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.baea_nests_gid_seq OWNER TO postgres;

--
-- Name: baea_nests_gid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.baea_nests_gid_seq OWNED BY public.baea_nests.gid;


--
-- Name: baea_survey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.baea_survey (
    id integer NOT NULL,
    nest integer,
    "user" character varying,
    date date,
    result character varying
);


ALTER TABLE public.baea_survey OWNER TO postgres;

--
-- Name: buowlL_survey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."buowlL_survey" (
    id integer NOT NULL,
    habitat integer,
    surveyor character varying,
    date date,
    result character varying
);


ALTER TABLE public."buowlL_survey" OWNER TO postgres;

--
-- Name: buowl_habitat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buowl_habitat (
    gid integer NOT NULL,
    postgis_fi double precision,
    habitat character varying(254),
    hist_occup character varying(254),
    recentstat character varying(254),
    habitat_id double precision,
    active2017 character varying(10),
    geom public.geometry(MultiPolygon,4326)
);


ALTER TABLE public.buowl_habitat OWNER TO postgres;

--
-- Name: buowl_habitat_gid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.buowl_habitat_gid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.buowl_habitat_gid_seq OWNER TO postgres;

--
-- Name: buowl_habitat_gid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.buowl_habitat_gid_seq OWNED BY public.buowl_habitat.gid;


--
-- Name: gbh_rook; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gbh_rook (
    id integer NOT NULL,
    geom public.geometry(MultiPolygon,4326),
    postgis_fi bigint,
    species character varying(254),
    activity character varying(254)
);


ALTER TABLE public.gbh_rook OWNER TO postgres;

--
-- Name: gbh_rook_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gbh_rook_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gbh_rook_id_seq OWNER TO postgres;

--
-- Name: gbh_rook_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gbh_rook_id_seq OWNED BY public.gbh_rook.id;


--
-- Name: linear_projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.linear_projects (
    id integer NOT NULL,
    geom public.geometry(MultiLineString,4326),
    postgis_fi bigint,
    type character varying(254),
    row_width numeric,
    project bigint
);


ALTER TABLE public.linear_projects OWNER TO postgres;

--
-- Name: linear_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.linear_projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.linear_projects_id_seq OWNER TO postgres;

--
-- Name: linear_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.linear_projects_id_seq OWNED BY public.linear_projects.id;


--
-- Name: raptor_active_sorted; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.raptor_active_sorted (
    id integer,
    "user" character varying,
    date date,
    nest integer,
    result_cd text
);


ALTER TABLE public.raptor_active_sorted OWNER TO postgres;

--
-- Name: raptor_by_surveyors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.raptor_by_surveyors (
    nest_count bigint,
    nest_avg numeric,
    "user" character varying
);


ALTER TABLE public.raptor_by_surveyors OWNER TO postgres;

--
-- Name: raptor_nests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.raptor_nests (
    id integer NOT NULL,
    geom public.geometry(Point,4326),
    postgis_fi bigint,
    lat_y_dd numeric,
    long_x_dd numeric,
    lastsurvey date,
    recentspec character varying(254),
    recentstat character varying(254),
    nest_id bigint,
    longitude double precision,
    latitude double precision
);


ALTER TABLE public.raptor_nests OWNER TO postgres;

--
-- Name: raptor_nests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.raptor_nests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.raptor_nests_id_seq OWNER TO postgres;

--
-- Name: raptor_nests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.raptor_nests_id_seq OWNED BY public.raptor_nests.id;


--
-- Name: raptor_survey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.raptor_survey (
    id integer NOT NULL,
    nest integer,
    "user" character varying,
    date date,
    result character varying
);


ALTER TABLE public.raptor_survey OWNER TO postgres;

--
-- Name: baea_nests gid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.baea_nests ALTER COLUMN gid SET DEFAULT nextval('public.baea_nests_gid_seq'::regclass);


--
-- Name: buowl_habitat gid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buowl_habitat ALTER COLUMN gid SET DEFAULT nextval('public.buowl_habitat_gid_seq'::regclass);


--
-- Name: gbh_rook id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gbh_rook ALTER COLUMN id SET DEFAULT nextval('public.gbh_rook_id_seq'::regclass);


--
-- Name: linear_projects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.linear_projects ALTER COLUMN id SET DEFAULT nextval('public.linear_projects_id_seq'::regclass);


--
-- Name: raptor_nests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raptor_nests ALTER COLUMN id SET DEFAULT nextval('public.raptor_nests_id_seq'::regclass);


--
-- Data for Name: baea_nests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.baea_nests (gid, postgis_fi, lat_y_dd, long_x_dd, status, nest_id, geom) FROM stdin;
\.
COPY public.baea_nests (gid, postgis_fi, lat_y_dd, long_x_dd, status, nest_id, geom) FROM '$$PATH$$/3933.dat';

--
-- Data for Name: baea_survey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.baea_survey (id, nest, "user", date, result) FROM stdin;
\.
COPY public.baea_survey (id, nest, "user", date, result) FROM '$$PATH$$/3944.dat';

--
-- Data for Name: buowlL_survey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."buowlL_survey" (id, habitat, surveyor, date, result) FROM stdin;
\.
COPY public."buowlL_survey" (id, habitat, surveyor, date, result) FROM '$$PATH$$/3943.dat';

--
-- Data for Name: buowl_habitat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buowl_habitat (gid, postgis_fi, habitat, hist_occup, recentstat, habitat_id, active2017, geom) FROM stdin;
\.
COPY public.buowl_habitat (gid, postgis_fi, habitat, hist_occup, recentstat, habitat_id, active2017, geom) FROM '$$PATH$$/3935.dat';

--
-- Data for Name: gbh_rook; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gbh_rook (id, geom, postgis_fi, species, activity) FROM stdin;
\.
COPY public.gbh_rook (id, geom, postgis_fi, species, activity) FROM '$$PATH$$/3937.dat';

--
-- Data for Name: linear_projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.linear_projects (id, geom, postgis_fi, type, row_width, project) FROM stdin;
\.
COPY public.linear_projects (id, geom, postgis_fi, type, row_width, project) FROM '$$PATH$$/3939.dat';

--
-- Data for Name: raptor_active_sorted; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.raptor_active_sorted (id, "user", date, nest, result_cd) FROM stdin;
\.
COPY public.raptor_active_sorted (id, "user", date, nest, result_cd) FROM '$$PATH$$/3945.dat';

--
-- Data for Name: raptor_by_surveyors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.raptor_by_surveyors (nest_count, nest_avg, "user") FROM stdin;
\.
COPY public.raptor_by_surveyors (nest_count, nest_avg, "user") FROM '$$PATH$$/3946.dat';

--
-- Data for Name: raptor_nests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.raptor_nests (id, geom, postgis_fi, lat_y_dd, long_x_dd, lastsurvey, recentspec, recentstat, nest_id, longitude, latitude) FROM stdin;
\.
COPY public.raptor_nests (id, geom, postgis_fi, lat_y_dd, long_x_dd, lastsurvey, recentspec, recentstat, nest_id, longitude, latitude) FROM '$$PATH$$/3941.dat';

--
-- Data for Name: raptor_survey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.raptor_survey (id, nest, "user", date, result) FROM stdin;
\.
COPY public.raptor_survey (id, nest, "user", date, result) FROM '$$PATH$$/3942.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/3767.dat';

--
-- Name: baea_nests_gid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.baea_nests_gid_seq', 70, true);


--
-- Name: buowl_habitat_gid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.buowl_habitat_gid_seq', 473, true);


--
-- Name: gbh_rook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gbh_rook_id_seq', 55, true);


--
-- Name: linear_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.linear_projects_id_seq', 1109, true);


--
-- Name: raptor_nests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.raptor_nests_id_seq', 876, true);


--
-- Name: baea_nests baea_nests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.baea_nests
    ADD CONSTRAINT baea_nests_pkey PRIMARY KEY (gid);


--
-- Name: baea_survey baea_survey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.baea_survey
    ADD CONSTRAINT baea_survey_pkey PRIMARY KEY (id);


--
-- Name: buowlL_survey buowlL_survey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."buowlL_survey"
    ADD CONSTRAINT "buowlL_survey_pkey" PRIMARY KEY (id);


--
-- Name: buowl_habitat buowl_habitat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buowl_habitat
    ADD CONSTRAINT buowl_habitat_pkey PRIMARY KEY (gid);


--
-- Name: gbh_rook gbh_rook_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gbh_rook
    ADD CONSTRAINT gbh_rook_pkey PRIMARY KEY (id);


--
-- Name: linear_projects linear_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.linear_projects
    ADD CONSTRAINT linear_projects_pkey PRIMARY KEY (id);


--
-- Name: raptor_nests raptor_nests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raptor_nests
    ADD CONSTRAINT raptor_nests_pkey PRIMARY KEY (id);


--
-- Name: raptor_survey raptor_survey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.raptor_survey
    ADD CONSTRAINT raptor_survey_pkey PRIMARY KEY (id);


--
-- Name: baea_nests_geom_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX baea_nests_geom_idx ON public.baea_nests USING gist (geom);


--
-- Name: buowl_habitat_geom_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX buowl_habitat_geom_idx ON public.buowl_habitat USING gist (geom);


--
-- Name: sidx_gbh_rook_geom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sidx_gbh_rook_geom ON public.gbh_rook USING gist (geom);


--
-- Name: sidx_linear_projects_geom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sidx_linear_projects_geom ON public.linear_projects USING gist (geom);


--
-- Name: sidx_raptor_nests_geom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sidx_raptor_nests_geom ON public.raptor_nests USING gist (geom);


--
-- PostgreSQL database dump complete
--

